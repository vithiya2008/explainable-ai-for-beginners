"""A tiny, transparent pass/fail model for teaching Explainable AI.

Same maths as the frontend demo:
  contribution = weight * (normalised value - 0.5) * 10
  logit        = BIAS + sum(contribution) / 10
  probability  = 1 / (1 + exp(-1.2 * logit))
"""
import math

BIAS = 0.4

FEATURES = [
    {"key": "study",  "name": "Study hours / day",   "min": 0, "max": 10,  "step": 0.5, "unit": "h", "weight": 2.2, "hint": "Regular study time"},
    {"key": "attend", "name": "Attendance",          "min": 0, "max": 100, "step": 1,   "unit": "%", "weight": 1.8, "hint": "Classes attended"},
    {"key": "prev",   "name": "Previous marks",      "min": 0, "max": 100, "step": 1,   "unit": "%", "weight": 3.0, "hint": "Last exam score"},
    {"key": "sleep",  "name": "Sleep hours / night", "min": 4, "max": 10,  "step": 0.5, "unit": "h", "weight": 0.7, "hint": "Rest before exams"},
    {"key": "assign", "name": "Assignments done",    "min": 0, "max": 100, "step": 1,   "unit": "%", "weight": 1.3, "hint": "Homework submitted"},
]

SAMPLES = {
    "steady":     {"study": 6, "attend": 92, "prev": 78, "sleep": 7.5, "assign": 95},
    "struggling": {"study": 2, "attend": 55, "prev": 48, "sleep": 5,   "assign": 40},
    "mixed":      {"study": 7, "attend": 60, "prev": 55, "sleep": 6,   "assign": 80},
}


class ValidationError(ValueError):
    pass


def validate(data):
    """Return a clean dict of floats or raise ValidationError with a clear message."""
    if not isinstance(data, dict):
        raise ValidationError("Send a JSON object with the student's data.")
    clean, errors = {}, []
    for f in FEATURES:
        k = f["key"]
        if k not in data:
            errors.append(f"'{k}' is missing.")
            continue
        v = data[k]
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            errors.append(f"'{k}' must be a number.")
            continue
        if not (f["min"] <= v <= f["max"]):
            errors.append(f"'{k}' must be between {f['min']} and {f['max']}.")
            continue
        clean[k] = float(v)
    if errors:
        raise ValidationError(" ".join(errors))
    return clean


def predict(student):
    parts = []
    for f in FEATURES:
        norm = (student[f["key"]] - f["min"]) / (f["max"] - f["min"])
        parts.append({
            "key": f["key"],
            "name": f["name"],
            "value": student[f["key"]],
            "unit": f["unit"],
            "hint": f["hint"],
            "contribution": round(f["weight"] * (norm - 0.5) * 10, 2),
        })
    logit = BIAS + sum(p["contribution"] for p in parts) / 10
    prob = 1 / (1 + math.exp(-1.2 * logit))
    return {
        "probability": round(prob, 4),
        "percent": round(prob * 100),
        "label": "PASS" if prob >= 0.5 else "FAIL",
        "contributions": parts,
    }


def explain(student):
    """Plain-language reasons for one prediction."""
    r = predict(student)
    ranked = sorted(r["contributions"], key=lambda p: abs(p["contribution"]), reverse=True)
    top = ranked[0]
    helps = [p for p in ranked if p["contribution"] > 0]
    hurts = [p for p in ranked if p["contribution"] < 0]

    def sentence(p):
        verb = "helps" if p["contribution"] > 0 else "hurts"
        return (f"{p['name']} is {p['value']:g}{p['unit']}, which {verb} "
                f"by {abs(p['contribution']):.1f} points.")

    direction = "pushed the result up" if top["contribution"] > 0 else "pulled the result down"
    summary = (f"The AI predicts a {r['percent']}% chance of passing. "
               f"The biggest factor was {top['name'].lower()}, which {direction}.")
    advice = (f"Improving {hurts[0]['name'].lower()} would help most."
              if hurts else "Every factor is above average. Keep these habits.")
    return {
        "prediction": {"percent": r["percent"], "label": r["label"]},
        "summary": summary,
        "pushing_toward_pass": [sentence(p) for p in helps],
        "pushing_toward_fail": [sentence(p) for p in hurts],
        "advice": advice,
        "contributions": r["contributions"],
    }


def importance():
    """Global importance: each feature's share of the total weight."""
    total = sum(f["weight"] for f in FEATURES)
    items = [{"key": f["key"], "name": f["name"], "percent": round(f["weight"] / total * 100)} for f in FEATURES]
    return sorted(items, key=lambda i: i["percent"], reverse=True)
