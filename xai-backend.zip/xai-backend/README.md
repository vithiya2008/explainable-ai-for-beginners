# XAI for Beginners - Backend (Flask)

A small REST API that powers the XAI for Beginners frontend. It runs the same
transparent pass/fail model as the frontend demo and returns predictions,
explanations and feature importance as JSON.

## Run

    python -m venv venv
    source venv/bin/activate        # Windows: venv\Scripts\activate
    pip install -r requirements.txt
    python app.py                   # http://localhost:5000

Optional environment variables: `PORT` (default 5000), `DEBUG=1`, `CORS_ORIGIN` (default `*`).

## Test

    python -m unittest test_api.py

## Endpoints

| Method | Route | What it returns |
|---|---|---|
| GET | /api/health | `{"status":"ok"}` |
| GET | /api/features | Feature names, ranges, units, weights |
| GET | /api/samples | Three sample students |
| POST | /api/predict | Pass chance, label and each factor's contribution |
| POST | /api/explain | Plain-language reasons and advice |
| GET | /api/importance | Overall importance of each factor (percent) |

### Example

    curl -X POST http://localhost:5000/api/predict \
      -H "Content-Type: application/json" \
      -d '{"study":6,"attend":92,"prev":78,"sleep":7.5,"assign":95}'

Errors come back as `{"error": "..."}` with status 400.

## Connect the frontend

Option A - one server: copy the frontend files into a folder named `frontend`
next to `app.py`. Flask will serve them at http://localhost:5000.

Option B - two servers: keep the frontend separate and call the API with fetch:

    const res = await fetch("http://localhost:5000/api/explain", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({study:6, attend:92, prev:78, sleep:7.5, assign:95})
    });
    const data = await res.json();

## Files

- app.py - routes, validation errors, CORS
- model.py - features, prediction, explanation, importance
- test_api.py - unit tests
- requirements.txt - dependencies
