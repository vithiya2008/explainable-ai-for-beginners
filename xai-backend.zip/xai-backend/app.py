"""XAI for Beginners - backend API (Flask).

Run:  python app.py        ->  http://localhost:5000
"""
import os
from flask import Flask, jsonify, request, send_from_directory

import model

app = Flask(__name__)

# Optional: serve the frontend folder too (put it next to this file as ./frontend)
FRONTEND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "frontend")


@app.after_request
def add_cors(resp):
    """Allow the frontend to call the API from another origin (e.g. opened as a file)."""
    resp.headers["Access-Control-Allow-Origin"] = os.environ.get("CORS_ORIGIN", "*")
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return resp


@app.errorhandler(model.ValidationError)
def bad_input(err):
    return jsonify(error=str(err)), 400


@app.errorhandler(404)
def not_found(_):
    return jsonify(error="Route not found."), 404


@app.errorhandler(405)
def wrong_method(_):
    return jsonify(error="Method not allowed for this route."), 405


def read_student():
    data = request.get_json(silent=True)
    if data is None:
        raise model.ValidationError("Send a JSON body with Content-Type: application/json.")
    return model.validate(data)


@app.get("/api/health")
def health():
    return jsonify(status="ok")


@app.get("/api/features")
def features():
    return jsonify(features=model.FEATURES)


@app.get("/api/samples")
def samples():
    return jsonify(samples=model.SAMPLES)


@app.post("/api/predict")
def predict():
    return jsonify(model.predict(read_student()))


@app.post("/api/explain")
def explain():
    return jsonify(model.explain(read_student()))


@app.get("/api/importance")
def importance():
    return jsonify(importance=model.importance())


@app.get("/")
def index():
    if os.path.isfile(os.path.join(FRONTEND_DIR, "index.html")):
        return send_from_directory(FRONTEND_DIR, "index.html")
    return jsonify(name="XAI for Beginners API", docs="See README.md", health="/api/health")


@app.get("/<path:path>")
def static_files(path):
    if os.path.isfile(os.path.join(FRONTEND_DIR, path)):
        return send_from_directory(FRONTEND_DIR, path)
    return jsonify(error="Route not found."), 404


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=os.environ.get("DEBUG") == "1")
