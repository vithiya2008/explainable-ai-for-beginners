"""Run:  python -m unittest test_api.py"""
import unittest
from app import app
import model


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.c = app.test_client()

    def test_health(self):
        self.assertEqual(self.c.get("/api/health").get_json()["status"], "ok")

    def test_steady_student_passes(self):
        r = self.c.post("/api/predict", json=model.SAMPLES["steady"]).get_json()
        self.assertEqual(r["label"], "PASS")
        self.assertEqual(len(r["contributions"]), 5)

    def test_struggling_student_fails(self):
        r = self.c.post("/api/predict", json=model.SAMPLES["struggling"]).get_json()
        self.assertEqual(r["label"], "FAIL")

    def test_explain_has_reasons(self):
        r = self.c.post("/api/explain", json=model.SAMPLES["mixed"]).get_json()
        self.assertTrue(r["summary"])
        self.assertTrue(r["pushing_toward_pass"] or r["pushing_toward_fail"])

    def test_missing_field(self):
        r = self.c.post("/api/predict", json={"study": 5})
        self.assertEqual(r.status_code, 400)
        self.assertIn("attend", r.get_json()["error"])

    def test_out_of_range(self):
        bad = dict(model.SAMPLES["steady"], attend=150)
        self.assertEqual(self.c.post("/api/predict", json=bad).status_code, 400)

    def test_no_json(self):
        self.assertEqual(self.c.post("/api/predict", data="hi").status_code, 400)

    def test_importance_sums_near_100(self):
        items = self.c.get("/api/importance").get_json()["importance"]
        self.assertAlmostEqual(sum(i["percent"] for i in items), 100, delta=2)


if __name__ == "__main__":
    unittest.main()
